// David Jones
var _inside = _inside || [];
// var _inside = [];
var _insideLoaded = _insideLoaded || false;
var _insideJQ = _insideJQ || null;
var _insideConnectImmediately = true;
window._insideViewUpdate = window._insideViewUpdate || function () { };

(function () {
	if (_insideLoaded) {
		window._insideViewUpdate();
		return;
	}
	_insideLoaded = true;

	var insideAccountKey = "IN-1000116";
	var insideTrackerURL = "au-cdn.inside-graph.com";
	var subsiteId = null;
	var insideOrderTotal = insideOrderTotal || 0;
	var _insideMaxLoop = 25;
	var _insideCurLoop = 0;
	var _insideFirstLoad = false;
	var _insideCurrency = null;

	// Utility Functions
	function log() {
		if (typeof (console) != "undefined" && typeof (console.log) != "undefined") {
			// console.log("[INSIDE]", Array.prototype.slice.call(arguments));
		}
	}

	var hashJoaat = function (b) { for (var a = 0, c = b.length; c--;)a += b.charCodeAt(c), a += a << 10, a ^= a >> 6; a += a << 3; a ^= a >> 11; return ((a + (a << 15) & 4294967295) >>> 0).toString(16) };

	function debounce(func, wait, immediate) {
		var timeout;
		return function () {
			var context = this, args = arguments;
			var later = function () {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
			var callNow = immediate && !timeout;
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
			if (callNow) func.apply(context, args);
		};
	};

	function deferWait(callback, test) {
		if (test()) {
			callback();
			return;
		}
		var _interval = 10;
		var _spin = function () {
			if (test()) {
				callback();
			}
			else {
				_interval = _interval >= 1000 ? 1000 : _interval * 2;
				setTimeout(_spin, _interval);
			}
		};
		setTimeout(_spin, _interval);
	}

	function keepWait(callback, test) {
		if (test()) {
			callback();
			if (_insideCurLoop >= _insideMaxLoop) {
				return;
			}
		}
		var _interval = 1000;
		var _spin = function () {
			if (test()) {
				_insideCurLoop = _insideCurLoop + 1;
				callback();
				if (_insideCurLoop >= _insideMaxLoop) {
					return;
				}
			}
			setTimeout(_spin, _interval);
		};
		setTimeout(_spin, _interval);
	}

	var indexOf = [].indexOf || function (prop) {
		for (var i = 0; i < this.length; i++) {
			if (this[i] === prop)
				return i;
		}
		return -1;
	};

	function myTrim(text) {
		try {
			if (typeof (text) != "undefined" && text != null)
				return typeof (text.trim) === "function" ? text.trim() : text.replace(/^\s+|\s+$/gm, '');
		} catch (trimex) { }

		return text;
	}

	function isNumeric(n) {
		try {
			return !isNaN(parseFloat(n)) && isFinite(n);
		}
		catch (tempex) {
		}

		return false;
	}

	function validateEmail(tempmail) {
		try {
			if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(tempmail)) {
				return (true);
			}
		} catch (tempex) { }
		return (false);
	}

	function setCookie(cname, cvalue, exdays) {
		var hostName = window.location.hostname;
		var siteNameFragments = hostName.split(".");
		var siteName = siteNameFragments[1];
		var domain = siteNameFragments.slice(1, siteNameFragments.length).join(".");

		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		var expires = "expires=" + d.toGMTString();
		document.cookie = cname + "=" + cvalue + "; " + expires + ";path=/" + ";domain=." + domain;
	}

	function getCookie(cname) {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = myTrim(ca[i]);
			if (c.indexOf(name) == 0)
				return c.substring(name.length, c.length);
		}
		return null;
	}

	function deleteCookie(cname) {
		document.cookie = cname + "=" + 0 + "; " + "expires=01 Jan 1970 00:00:00 GMT" + ";path=/";
	}

	function roundToTwo(num) {
		if (Math != "undefined" && Math.round != "undefined")
			return +(Math.round(num + "e+2") + "e-2");
		else
			return num;
	}

	function getSearchParameters() {
		var prmstr = window.location.search.substring(1);
		return prmstr != null && prmstr != "" ? transformToAssocArray(prmstr) : [];
	}

	function transformToAssocArray(prmstr) {
		var params = [];
		var prmarr = prmstr.split("&");
		for (var i = 0; i < prmarr.length; i++) {
			params[i] = prmarr[i];
		}

		return params;
	}

	function randomIntFromInterval(min, max) {
		try {
			return Math.floor(Math.random() * (max - min + 1) + min);
		}
		catch (tempex) {
		}

		return min;
	}

	function getDecimalSign(number) {
		try {
			var tempnum = myTrim(number);

			if (tempnum.length > 3) {
				return tempnum.charAt(tempnum.length - 3);
			}
		}
		catch (signex) {
		}

		return ".";
	}

	// End of utility functions

	function processInside(tracker) {
		var searchUrl = "search?q=";
		var searchQueryString = null;
		var productCategoryUrl = null;
		var productCategoryQueryString = 'section[class*="Listing_content"]';
		var productUrl = null;
		var productQueryString = 'div[class*="ProductControls_productInfo"]';
		var checkoutUrl = null;
		var checkoutQueryString = null;
		var orderConfirmedUrl = null;
		var orderConfirmedQueryString = null;

		function getViewData() {
			try {

				// Output view data
				// Default view data is "unknown"

				var insidedata = {};

				insidedata.action = "trackView";
				insidedata.type = "article";
				insidedata.url = window.location.href;
				insidedata.name = "Unknown Page: " + window.location.href;
				var tempurl = window.location.href.toLowerCase();

				var temppath = window.location.pathname;
				var temp_loc = temppath.split("/");
				var page = "";

				var add_tags = [];
				var params = getSearchParameters();
				var searchterm = "Search"; // Find the searchterm the
				// visitor
				// entered for the search page to be
				// used as the page name
				if (params != null && params.length > 0) {
					for (var i = 0; i < params.length; i++) {
						if (params[i].indexOf("q=") == 0) {
							searchterm = params[i].split("q=")[1];
						}
					}
				}

				for (var i = 1; i < temp_loc.length; i++) {
					if (temp_loc[i] != null && temp_loc[i].length > 0) {
						if (temp_loc[i].indexOf("?") != -1) {
							var temploc = temp_loc[i].split("?")[0];
							if (temploc.length > 0)
								page = temp_loc[i];
						}
						else {
							page = temp_loc[i];
						}
					}
				}
				var curpage = page.split("?")[0];
				insidedata.name = curpage;

				// Identify and assign the correct page type here
				// The part below is actually very flexible, can use
				// dataLayer too
				// sometimes, etc so if needed can also just delete the
				// global
				// variable parts and make your own algorithm. From my
				// experience
				// the following part will rarely work for all websites.

				var temppagetype = "other";
				try {
					if (typeof (_insideData) != "undefined" && _insideData != null && typeof (_insideData.page) != "undefined" && _insideData.page != null && typeof (_insideData.page.type) != "undefined" && _insideData.page.type != null && _insideData.page.type.length > 0) {
						temppagetype = _insideData.page.type.toLowerCase();
					}
				} catch (tempex) { }

				if ((temppath == "/" || curpage == "index.html") && temp_loc.length < 3) {
					insidedata.type = "homepage";
				}
				else if (temppagetype == "homepage") {
					insidedata.type = "homepage";
				}
				else if (temppagetype == "search") {
					insidedata.type = "search";
				}
				else if (temppagetype == "category" || temppagetype == "productcategory") {
					insidedata.type = "productcategory";
				}
				else if (temppagetype == "product") {
					insidedata.type = "product";
				}
				else if (tempurl.indexOf("/login") != -1 || tempurl.indexOf("/register") != -1) {
					insidedata.type = "login";
				}

				if (productCategoryUrl != null) {
					if (tempurl.indexOf(productCategoryUrl.toLowerCase()) > -1) {
						insidedata.type = "productcategory";
					}
				}
				if (productCategoryQueryString != null) {
					var tempelem = _insideJQ(productCategoryQueryString);
					if (tempelem != null && tempelem.length > 0) {
						insidedata.type = "productcategory";
					}
				}

				if (searchUrl != null) {
					if (tempurl.indexOf(searchUrl.toLowerCase()) > -1) {
						insidedata.type = "search";
					}
				}
				if (searchQueryString != null) {
					var tempelem = _insideJQ(searchQueryString);
					if (tempelem != null && tempelem.length > 0) {
						insidedata.type = "search";
					}
				}

				if (productUrl != null) {
					if (tempurl.indexOf(productUrl.toLowerCase()) > -1) {
						insidedata.type = "product";
					}
				}
				if (productQueryString != null) {
					var tempelem = _insideJQ(productQueryString);
					if (tempelem != null && tempelem.length > 0) {
						insidedata.type = "product";
					}
				}

				if (checkoutUrl != null) {
					if (tempurl.search(checkoutUrl.toLowerCase()) > 0) {
						insidedata.type = "checkout";
					}
				}
				if (checkoutQueryString != null) {
					var tempelem = _insideJQ(checkoutQueryString);
					if (tempelem != null && tempelem.length > 0) {
						insidedata.type = "checkout";
					}
				}

				if (orderConfirmedUrl != null) {
					if (tempurl.indexOf(orderConfirmedUrl.toLowerCase()) > -1) {
						insidedata.type = "orderconfirmed";
					}
				}
				if (orderConfirmedQueryString != null) {
					var tempelem = _insideJQ(orderConfirmedQueryString);
					if (tempelem != null && tempelem.length > 0) {
						insidedata.type = "orderconfirmed";
					}
				}

				// Finish identying

				switch (insidedata.type) {
					case "homepage":
						insidedata.name = "Home";
						break;
					case "search":
						insidedata.name = "Search Result Page";
						if (searchterm != null && searchterm.length > 0) {
							insidedata.name = decodeURIComponent(searchterm);
							if (insidedata.name.indexOf("+") != -1) {
								insidedata.name = insidedata.name.replace(/\+/g, ' ');
							}
						}
						break;
					case "productcategory":
						var tempcat = getCategory();
						if (tempcat != null && tempcat.length > 0) {
							if (tempcat.length > 149)
								tempcat = tempcat.substring(0, 149);
							insidedata.category = tempcat;
						}

						var tempPageName = getPageName();
						if (tempPageName != null && tempPageName.length > 0)
							insidedata.name = tempPageName;

						break;
					case "product":
						var tempPageName = getPageName();
						if (tempPageName != null && tempPageName.length > 0)
							insidedata.name = tempPageName;

						tempPageName = getProductName();
						if (tempPageName != null && tempPageName.length > 0)
							insidedata.name = tempPageName;

						var tempcat = getCategory();
						if (tempcat != null && tempcat.length > 0) {
							if (tempcat.length > 149)
								tempcat = tempcat.substring(0, 149);
							insidedata.category = tempcat;
						}

						var tempval = getProductImage();
						if (tempval != null && tempval.length > 0) {
							insidedata.img = tempval;
						}
						else
							insidedata.type = "other";

						var tempsku = getProductSku();
						if (tempsku != null && tempsku.length > 0) {
							insidedata.sku = tempsku;
							insidedata.name = insidedata.name + " - " + tempsku;
						}
						else {
							insidedata.type = "other";
						}

						var tempprice = getProductPrice();
						if (tempprice != null && tempprice > 0)
							insidedata.price = tempprice;

						try {
							if (typeof (_insideData) != "undefined" && _insideData.product && _insideData.product.brand && _insideData.product.brand.length > 0) {
								if (typeof (insidedata.data) == "undefined")
									insidedata.data = {};
								insidedata.data.brand = _insideData.product.brand;
							}
							else if (typeof (dataLayer) != "undefined" && dataLayer != null && dataLayer.length > 0) {
								for (var i = dataLayer.length - 1; i >= 0; i--) {
									// for (var i = 0; i < dataLayer.length; i++) {
									if (typeof (dataLayer[i]) != "undefined" && dataLayer[i] != null && typeof (dataLayer[i].event) != "undefined" && dataLayer[i].event != null && dataLayer[i].event == "view_item" && typeof (dataLayer[i].ecommerce) != "undefined" && dataLayer[i].ecommerce != null
										&& typeof (dataLayer[i].ecommerce.items) != "undefined" && dataLayer[i].ecommerce.items != null && dataLayer[i].ecommerce.items.length > 0) {
										if (dataLayer[i].ecommerce.items[0].item_brand) {
											if (typeof (insidedata.data) == "undefined")
												insidedata.data = {};
											insidedata.data.brand = dataLayer[i].ecommerce.items[0].item_brand;
											break;
										}
									}
								}
							}
						} catch (brandex) { }
						break;
					case "orderconfirmed":
						insidedata.name = "Order Confirmed";
						break;
					default:
						var tempPageName = getPageName();
						if (tempPageName != null && tempPageName.length > 0)
							insidedata.name = tempPageName;
				}

				if (add_tags.length > 0) {
					insidedata.tags = add_tags.join(",");
				}

				// Get view insidedata from page

				return insidedata;
			}
			catch (ex) {
				log("getViewData error: ", ex);

				var insidedata = {};

				insidedata.action = "trackView";
				insidedata.type = "other";
				insidedata.url = window.location.href;
				insidedata.name = "Error: " + window.location.href;

				return insidedata;
			}
		}

		function getPageName() {
			// Modify if necessary
			try {
				var content = document.getElementsByTagName("title");
				if (typeof (content) != "undefined" && content != null && content.length > 0) {
					var result = content[0].textContent || content[0].innerText;
					if (typeof (result) != "undefined" && result != null && result.length > 0) {
						return myTrim(result);
					}
				}
			} catch (pagenameex) { }

			return null;
		}

		function getProductName() {
			try {
				if (typeof (_insideData) != "undefined" && _insideData.product && _insideData.product.name && _insideData.product.name.length > 0) {
					return _insideData.product.name;
				}
			} catch (tempex) { }

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "Product" && typeof (tempdetail.name) != "undefined" && tempdetail.name != null && tempdetail.name.length > 0) {
								if (_insideJQ.isArray(tempdetail.name)) {
									return tempdetail.name[0];
								}
								else
									return tempdetail.name;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "Product" && typeof (tempdata.name) != "undefined" && tempdata.name != null && tempdata.name.length > 0) {
						if (_insideJQ.isArray(tempdata.name)) {
							return tempdata.name[0];
						}
						else
							return tempdata.name;
					}
				}
			}
			catch (tempex) {
			}

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "ProductGroup" && typeof (tempdetail.name) != "undefined" && tempdetail.name != null && tempdetail.name.length > 0) {
								if (_insideJQ.isArray(tempdetail.name)) {
									return tempdetail.name[0];
								}
								else
									return tempdetail.name;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "ProductGroup" && typeof (tempdata.name) != "undefined" && tempdata.name != null && tempdata.name.length > 0) {
						if (_insideJQ.isArray(tempdata.name)) {
							return tempdata.name[0];
						}
						else
							return tempdata.name;
					}
				}
			}
			catch (tempex) {
			}

			return null;
		}

		function getProductImage() {
			try {
				if (typeof (_insideData) != "undefined" && _insideData.product && _insideData.product.image && _insideData.product.image.length > 0) {
					return _insideData.product.image;
				}
			} catch (tempex) { }

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "Product" && typeof (tempdetail.image) != "undefined" && tempdetail.image != null && tempdetail.image.length > 0) {
								if (_insideJQ.isArray(tempdetail.image)) {
									return tempdetail.image[0];
								}
								else
									return tempdetail.image;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "Product" && typeof (tempdata.image) != "undefined" && tempdata.image != null && tempdata.image.length > 0) {
						if (_insideJQ.isArray(tempdata.image)) {
							return tempdata.image[0];
						}
						else
							return tempdata.image;
					}
				}
			}
			catch (tempex) {
			}

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "ProductGroup" && typeof (tempdetail.image) != "undefined" && tempdetail.image != null && tempdetail.image.length > 0) {
								if (_insideJQ.isArray(tempdetail.image)) {
									return tempdetail.image[0];
								}
								else
									return tempdetail.image;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "ProductGroup" && typeof (tempdata.image) != "undefined" && tempdata.image != null && tempdata.image.length > 0) {
						if (_insideJQ.isArray(tempdata.image)) {
							return tempdata.image[0];
						}
						else
							return tempdata.image;
					}
				}
			}
			catch (tempex) {
			}

			try {
				var metaTags = document.getElementsByTagName("meta");

				var fbAppIdContent = "";
				for (var i = 0; i < metaTags.length; i++) {
					if (metaTags[i].getAttribute("property") == "og:image") {
						fbAppIdContent = metaTags[i].getAttribute("content");
						if (fbAppIdContent)
							return fbAppIdContent;
					}
				}
			}
			catch (tempex) {
			}

			return null;
		}

		function getProductPrice() {
			try {
				if (typeof (_insideData) != "undefined" && _insideData.product && _insideData.product.price) {
					return _insideData.product.price;
				}
			} catch (tempex) { }

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "Product" && tempdetail.offers && typeof (tempdetail.offers.highPrice) != "undefined" && tempdetail.offers.highPrice != null && tempdetail.offers.highPrice.length > 0) {
								if (_insideJQ.isArray(tempdetail.offers.highPrice)) {
									return tempdetail.offers.highPrice[0];
								}
								else
									return tempdetail.offers.highPrice;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "Product" && tempdetail.offers && typeof (tempdata.offers.highPrice) != "undefined" && tempdata.offers.highPrice != null && tempdata.offers.highPrice.length > 0) {
						if (_insideJQ.isArray(tempdata.offers.highPrice)) {
							return tempdata.offers.highPrice[0];
						}
						else
							return tempdata.offers.highPrice;
					}
				}
			}
			catch (tempex) {
			}

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "ProductGroup" && tempdetail.offers && typeof (tempdetail.offers.highPrice) != "undefined" && tempdetail.offers.highPrice != null && tempdetail.offers.highPrice.length > 0) {
								if (_insideJQ.isArray(tempdetail.offers.highPrice)) {
									return tempdetail.offers.highPrice[0];
								}
								else
									return tempdetail.offers.highPrice;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "ProductGroup" && tempdetail.offers && typeof (tempdata.offers.highPrice) != "undefined" && tempdata.offers.highPrice != null && tempdata.offers.highPrice.length > 0) {
						if (_insideJQ.isArray(tempdata.offers.highPrice)) {
							return tempdata.offers.highPrice[0];
						}
						else
							return tempdata.offers.highPrice;
					}
				}
			}
			catch (tempex) {
			}

			return null;
		}

		function getProductSku() {
			try {
				if (typeof (_insideData) != "undefined" && _insideData.product && _insideData.product.sku) {
					return _insideData.product.sku;
				}
			} catch (tempex) { }

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "Product" && typeof (tempdetail.productID) != "undefined" && tempdetail.productID != null && tempdetail.productID.length > 0) {
								if (_insideJQ.isArray(tempdetail.productID)) {
									return tempdetail.productID[0];
								}
								else
									return tempdetail.productID;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "Product" && typeof (tempdata.productID) != "undefined" && tempdata.productID != null && tempdata.productID.length > 0) {
						if (_insideJQ.isArray(tempdata.productID)) {
							return tempdata.productID[0];
						}
						else
							return tempdata.productID;
					}
				}
			}
			catch (tempex) {
			}

			try {
				var ldjsons = _insideJQ('script[type="application/ld+json"]');
				for (var i = 0; i < ldjsons.length; i++) {
					var tempdata = JSON.parse(_insideJQ(ldjsons[i]).last().html().replace(/\n/g, ""));
					console.log(tempdata)
					if (typeof (tempdata) != "undefined" && tempdata != null && _insideJQ.isArray(tempdata)) {
						for (var l = 0; l < tempdata.length; l++) {
							var tempdetail = tempdata[i];
							if (typeof (tempdetail) != "undefined" && tempdetail != null && typeof (tempdetail["@type"]) != "undefined" && tempdetail["@type"] != null && tempdetail["@type"] == "ProductGroup" && typeof (tempdetail.productID) != "undefined" && tempdetail.productID != null && tempdetail.productID.length > 0) {
								if (_insideJQ.isArray(tempdetail.productID)) {
									return tempdetail.productID[0];
								}
								else
									return tempdetail.productID;
							}
						}
					}
					else if (typeof (tempdata) != "undefined" && tempdata != null && typeof (tempdata["@type"]) != "undefined" && tempdata["@type"] != null && tempdata["@type"] == "ProductGroup" && typeof (tempdata.productID) != "undefined" && tempdata.productID != null && tempdata.productID.length > 0) {
						if (_insideJQ.isArray(tempdata.productID)) {
							return tempdata.productID[0];
						}
						else
							return tempdata.productID;
					}
				}
			}
			catch (tempex) {
			}

			return null;
		}

		function getCategory() {
			try {
				var breadcrumbs = _insideJQ(".breadcrumbs");

				if (breadcrumbs != null && breadcrumbs.length > 0) {
					var path = "";
					for (var i = 1; i < breadcrumbs.length; i++) {
						var temp = breadcrumbs[i].innerText || breadcrumbs[i].textContent;
						var tempelem = breadcrumbs[i].getElementsByTagName("a");
						if (tempelem != null && tempelem.length > 0) {
							temp = tempelem[0].innerText || tempelem[0].textContent;
						}
						temp = myTrim(temp);
						if (temp != "/")
							path += (path != "" ? " / " : "") + temp;
					}
					if (path != "")
						return path;

				}
			}
			catch (tempex) {
			}

			return null;
		}

		function getOrderData() {
			try {
				var data = [];
				var totalprice = 0;
				var orderId = "auto";
				var dataLayerTotal = 0;

				var tempcartitems = null;
				if (typeof (dataLayer) != "undefined" && dataLayer != null && dataLayer.length > 0) {
					for (var i = dataLayer.length - 1; i >= 0; i--) {
						if (typeof (dataLayer[i]) != "undefined" && dataLayer[i] != null && typeof (dataLayer[i].event) != "undefined" && dataLayer[i].event != null && (dataLayer[i].event == "view_cart" || dataLayer[i].event == "begin_checkout" || dataLayer[i].event == "add_shipping_info") && typeof (dataLayer[i].ecommerce) != "undefined" && dataLayer[i].ecommerce != null
							&& typeof (dataLayer[i].ecommerce.items) != "undefined" && dataLayer[i].ecommerce.items != null
							&& dataLayer[i].ecommerce.items.length > 0) {
							tempcartitems = dataLayer[i].ecommerce.items;
							if (dataLayer[i].ecommerce.value && isNumeric(dataLayer[i].ecommerce.value)) {
								dataLayerTotal = dataLayer[i].ecommerce.value;
							}
							break;
						}
					}
				}

				if (tempcartitems != null && tempcartitems.length > 0) {
					var tempimgs = _insideJQ("#app-main .chakra-stack img.chakra-image");

					for (var i = 0; i < tempcartitems.length; i++) {
						var insideitem = {};
						insideitem.action = "addItem";
						insideitem.orderId = orderId;
						var tempitem = tempcartitems[i];
						insideitem.sku = tempitem.item_id;
						insideitem.name = tempitem.item_name;
						insideitem.price = parseFloat(tempitem.price);
						insideitem.qty = parseFloat(tempitem.quantity);

						totalprice = totalprice + (insideitem.price * insideitem.qty);

						try {
							if (tempitem.item_category) {
								insideitem.category = tempitem.item_category;
								if (insideitem.category.length > 149)
									insideitem.category = insideitem.category.substring(0, 149);
							}
						} catch (tempex) { }

						try {
							if (tempimgs.length == tempcartitems.length) {
								insideitem.img = tempimgs.get(i).currentSrc;
							}
						} catch (tempex) { }

						data.push(insideitem);
					}

					if (data.length > 0) {

						try {
							if (dataLayerTotal) {
								totalprice = parseFloat(dataLayerTotal);
							}
						} catch (tempex) { }

						data.push({
							"action": "trackOrder",
							"orderId": "auto",
							"orderTotal": totalprice
						});

						sessionStorage.setItem("insideordertotal", totalprice);

						return data;
					}
				}
			}
			catch (ex) {
				log("getOrderData error. ", ex);
			}

			try {
				var data = [];
				var totalprice = 0;
				var orderId = "auto";

				if (typeof (_insideData) != "undefined" && _insideData != null && _insideData.cart.items) {
					_insideJQ.each(_insideData.cart.items, function (tempindex, tempitem) {
						var insideitem = {};
						insideitem.action = "addItem";
						insideitem.orderId = orderId;
						insideitem.name = tempitem.name;
						insideitem.price = parseFloat(tempitem.price);
						insideitem.qty = parseFloat(tempitem.qty);
						insideitem.sku = tempitem.sku;
						insideitem.img = tempitem.image;
						try {
							if (tempitem.category) {
								insideitem.category = tempitem.category;
								if (insideitem.category.length > 149)
									insideitem.category = insideitem.category.substring(0, 149);
							}

							if (typeof (tempitem.name) == "undefined") {
								insideitem.name = insideitem.sku;
							}
						} catch (tempex) { }

						if (tempitem.itemurl) {
							insideitem.url = tempitem.itemurl;
						}

						if (insideitem.name && insideitem.sku && insideitem.qty) {
							totalprice = totalprice + (insideitem.qty * insideitem.price);

							data.push(insideitem);
						}
					});
				}

				if (data.length > 0) {
					try {
						if (_insideData.cart.total && isNumeric(_insideData.cart.total))
							totalprice = _insideData.cart.total;
					} catch (totalex) { }

					data.push({
						"action": "trackOrder",
						"orderId": orderId,
						"orderTotal": totalprice
					});

					sessionStorage.setItem("insideordertotal", totalprice);

					return data;
				}
			}
			catch (ex) {
				log("getOrderData error. ", ex);
			}

			return null;
		}

		function orderConfirmProcess() {
			try {
				var data = [];
				var tempcurrency = null;

				var detail = null;
				if (typeof (_insideData) != "undefined" && _insideData != null && _insideData.order && _insideData.order.total && _insideData.order.id) {
					detail = _insideData.order;
				}

				if (detail != null) {
					var totalprice = detail.total;
					var orderID = detail.id;
					var temppurchasedata = {};

					if (typeof (detail.shipping) != "undefined" && detail.shipping != null) {
						temppurchasedata.shipping = detail.shipping;
					}
					if (typeof (detail.tax) != "undefined" && detail.tax != null) {
						temppurchasedata.tax = detail.tax;
					}
					if (tempcurrency != null) {
						temppurchasedata.currency = tempcurrency;
					}

					if (typeof (orderID) != "undefined" && orderID != null && orderID != "auto") {
						try {
							var lastOrderID = sessionStorage.getItem("insidelastorderid");
							if (lastOrderID == orderID) {
								return null;
							}
						}
						catch (orderidex) {
						}

						data.push({
							"action": "trackOrder",
							"orderId": "auto",
							"newOrderId": orderID,
							"orderTotal": totalprice,
							"data": temppurchasedata,
							"update": true,
							"complete": true
						});

						return data;
					}
				}
			}
			catch (ex) {
				log("orderConfirmProcess error. ", ex);
			}

			try {
				var data = [];
				var tempcurrency = null;

				var detail = null;
				if (typeof (dataLayer) != "undefined" && dataLayer != null && dataLayer.length > 0) {
					for (var i = 0; i < dataLayer.length; i++) {
						if (typeof (dataLayer[i]) != "undefined" && dataLayer[i] != null && typeof (dataLayer[i].ecommerce) != "undefined" && dataLayer[i].ecommerce != null
							&& typeof (dataLayer[i].ecommerce.purchase) != "undefined" && dataLayer[i].ecommerce.purchase != null
							&& typeof (dataLayer[i].ecommerce.purchase.actionField) != "undefined"
							&& dataLayer[i].ecommerce.purchase.actionField != null
							&& typeof (dataLayer[i].ecommerce.purchase.actionField.id) != "undefined"
							&& dataLayer[i].ecommerce.purchase.actionField.id != null
							&& dataLayer[i].ecommerce.purchase.actionField.id.length > 0) {
							detail = dataLayer[i].ecommerce.purchase;
							if (typeof (dataLayer[i].ecommerce.currencyCode) != "undefined" && dataLayer[i].ecommerce.currencyCode != null && dataLayer[i].ecommerce.currencyCode.length > 0) {
								tempcurrency = dataLayer[i].ecommerce.currencyCode.toUpperCase();
							}
						}
					}
				}

				if (detail != null) {
					var totalprice = detail.actionField.revenue;
					var orderID = detail.actionField.id;
					var temppurchasedata = {};

					if (typeof (orderID) != "undefined" && orderID != null && orderID != "auto") {
						try {
							var lastOrderID = sessionStorage.getItem("insidelastorderid");
							if (lastOrderID == orderID) {
								return null;
							}

							if (typeof (detail.actionField.shipping) != "undefined" && detail.actionField.shipping != null) {
								temppurchasedata.shipping = detail.actionField.shipping;
							}
							if (typeof (detail.actionField.tax) != "undefined" && detail.actionField.tax != null) {
								temppurchasedata.tax = detail.actionField.tax;
							}
							if (tempcurrency != null) {
								temppurchasedata.currency = tempcurrency;
							}
						}
						catch (orderidex) {
						}

						try {
							// var details = detail.products;

							// for (var i = 0; i < details.length; i++)
							// {
							// var price = details[i].price;
							// var qty = details[i].quantity;
							// var item_name = details[i].name;
							// var sku = details[i].id;
							//
							// data.push({
							// "action" : "addItem",
							// "orderId" : "auto",
							// "name" : myTrim(item_name),
							// "price" : price,
							// "img" : details[i].ImageURL,
							// "sku" : myTrim(sku),
							// "qty" : qty
							// });
							// }

							// data.push({
							// "action" : "trackOrder",
							// "orderId" : "auto",
							// "orderTotal" : totalprice
							// });
						} catch (itemex) { }

						data.push({
							"action": "trackOrder",
							"orderId": "auto",
							"newOrderId": orderID,
							"orderTotal": totalprice,
							"data": temppurchasedata,
							"update": true,
							"complete": true
						});

						return data;
					}
				}
			}
			catch (ex) {
				log("orderConfirmProcess error. ", ex);
			}

			try {
				var data = [];
				var tempcurrency = null;

				var detail = null;
				if (typeof (dataLayer) != "undefined" && dataLayer != null && dataLayer.length > 0) {
					for (var i = dataLayer.length - 1; i >= 0; i--) {
						if (typeof (dataLayer[i]) != "undefined" && dataLayer[i] != null && dataLayer[i].event && dataLayer[i].event == "purchase" && typeof (dataLayer[i].ecommerce) != "undefined" && dataLayer[i].ecommerce != null && typeof (dataLayer[i].ecommerce.transaction_id) != "undefined" && dataLayer[i].ecommerce.transaction_id != null && dataLayer[i].ecommerce.transaction_id && typeof (dataLayer[i].ecommerce.value) != "undefined" && dataLayer[i].ecommerce.value != null) {
							detail = dataLayer[i].ecommerce;
							break;
						}
					}
				}

				if (detail != null) {
					var totalprice = detail.value;
					var orderID = detail.transaction_id;
					var temppurchasedata = {};

					if (typeof (orderID) != "undefined" && orderID != null && orderID != "auto") {

						try {
							var lastOrderID = sessionStorage.getItem("insidelastorderid");
							if (lastOrderID == orderID) {
								return null;
							}

							if (typeof (detail.shipping) != "undefined" && detail.shipping != null && detail.shipping) {
								temppurchasedata.shipping = detail.shipping;
							}
							if (typeof (detail.tax) != "undefined" && detail.tax != null && detail.tax) {
								temppurchasedata.tax = detail.tax;
							}
							if (tempcurrency != null) {
								temppurchasedata.currency = tempcurrency;
							}
						}
						catch (orderidex) {
						}

						data.push({
							"action": "trackOrder",
							"orderId": "auto",
							"newOrderId": orderID,
							"orderTotal": totalprice,
							"data": temppurchasedata,
							"update": true,
							"complete": true
						});
					}

					return data;
				}
			}
			catch (ex) {
				log("orderConfirmProcess error. ", ex);
			}

			return null;
		}

		function getVisitorId() {
			try {
				if (typeof (_insideData) != "undefined" && _insideData != null && _insideData.user && _insideData.user.id)
					return _insideData.user.id;
			}
			catch (visitidex) {
			}

			return null;
		}

		function getVisitorName() {
			try {
				if (typeof (_insideData) != "undefined" && _insideData != null && _insideData.user && _insideData.user.name)
					return _insideData.user.name;
			}
			catch (visitidex) {
			}

			return null;
		}

		function getVisitorData() {
			try {
				var tempdata = {};

				if (typeof (_insideData) != "undefined" && _insideData != null && _insideData.website && _insideData.website.country) {
					tempdata.country = _insideData.website.country.toUpperCase();
				}

				if (typeof (_insideData) != "undefined" && _insideData != null && _insideData.website && _insideData.website.language) {
					tempdata.language = _insideData.website.language.toUpperCase();
				}

				var tempuserid = getVisitorId();
				var tempusername = getVisitorName();
				if (tempuserid != null && tempusername != null && tempusername.length > 0) {
					tempdata.user_name = tempusername;
					if (typeof (_insideData.user.email) != "undefined" && _insideData.user.email != null && validateEmail(_insideData.user.email))
						tempdata.user_email = _insideData.user.email;
				}

				let tempuserstate = _insideData.user.displayStateId;
				if (tempuserstate) {
					tempdata.user_state = tempuserstate;
					tempdata.isDJRMember = "No";
					tempdata.isStaff = "No";
					tempdata.isFinancialServices = "N/A";
					if (tempuserstate == "1") {
						tempdata.isDJRMember = "Yes";
					}
					else if (tempuserstate == "7") {
						tempdata.isFinancialServices = "Amex Gold";
					}
					else if (tempuserstate == "33") {
						tempdata.isFinancialServices = "Amex Store";
					}
					else if (tempuserstate == "34") {
						tempdata.isFinancialServices = "Amex Platinum";
					}
					else if (tempuserstate == "41") {
						tempdata.isFinancialServices = "DJ Icon Card";
					}
					else if (tempuserstate == "42") {
						tempdata.isFinancialServices = "DJ Premiere Card";
					}
					else if (tempuserstate == "43") {
						tempdata.isFinancialServices = "DJ Prestige Card";
					}
					else if (tempuserstate == "44") {
						tempdata.isFinancialServices = "Staff Icon Card";
					}
					else if (tempuserstate == "45") {
						tempdata.isFinancialServices = "Staff Premiere Card";
					}
					else if (tempuserstate == "46") {
						tempdata.isFinancialServices = "Staff Prestige Card";
					}
					else if (tempuserstate == "4" || tempuserstate == "37") {
						tempdata.isStaff = "Yes";
					}
				}
			}
			catch (visitidex) {
			}


			return tempdata;
		}

		function insertInsideTag() {
			try {
				_insideGraph.processQueue();
			}
			catch (tempex) {
			}
		}

		function sendToInside() {
			try {
				tracker.url = window.location.href;

				var view = getViewData();

				var visitorId = getVisitorId();
				if (visitorId) {
					tracker.visitorId = visitorId;
				}

				var visitorName = getVisitorName();
				if (visitorName != null && visitorName.length > 0) {
					tracker.visitorName = visitorName;
				}

				var visitorData = getVisitorData();
				if (visitorData != null) {
					tracker.visitorData = visitorData;
				}

				if (view != null) {
					if (view.type == "orderconfirmed") {
						var tempconfirm = orderConfirmProcess();
						if (tempconfirm != null && tempconfirm.length > 0) {
							for (var i = 0; i < tempconfirm.length; i++) {
								_inside.push(tempconfirm[i]);

								try {
									if (tempconfirm[i].action == "trackOrder")
										if (typeof (tempconfirm[i].newOrderId) != "undefined" && tempconfirm[i].newOrderId != null)
											sessionStorage.setItem("insidelastorderid", tempconfirm[i].newOrderId);
								}
								catch (tempex) {
								}
							}

							sessionStorage.removeItem("insideordertotal");
						}
						else {
							view.type = "orderconfirmedother";
						}
					}
					else {
						var orderData = getOrderData();

						if (orderData != null && orderData.length > 0) {
							for (var i = 0; i < orderData.length; i++) {
								_inside.push(orderData[i]);
								if (orderData[i].action == "trackOrder") {
									view.orderId = orderData[i].orderId;
									view.orderTotal = orderData[i].orderTotal;
									insideOrderTotal = orderData[i].orderTotal;
								}
							}
						}
						else {
							try {
								if (view.url.indexOf("/cart") != -1) {
									sessionStorage.removeItem("insideordertotal");
								}
								else {
									var temptotal = sessionStorage.getItem("insideordertotal");
									if (temptotal != null) {
										var tempcount = _insideJQ(".minicart .item-count").text();
										tempcount = parseFloat(tempcount.replace(/[^0-9\.\-\+]/g, ""));

										if (isNumeric(tempcount) && tempcount > 0) {
											view.orderId = "auto";
											view.orderTotal = temptotal;
										}
									}
								}
							} catch (tempex) { }
						}
					}

					// Add currency code
					try {
						try {
							if (typeof (_insideData) != "undefined" && _insideData != null && _insideData.website && _insideData.website.currency && _insideData.website.currency.length == 3) {
								_insideCurrency = _insideData.website.currency.toUpperCase();
							}
						} catch (currencyex) { }

						if (_insideCurrency) {
							if (_inside != null && _inside.length > 0) {
								for (var i = 0; i < _inside.length; i++) {
									if (_inside[i].action == "trackOrder") {
										if (typeof (_inside[i].data) == "undefined" || _inside[i].data == null) {
											_inside[i].data = {};
										}

										if (typeof (_inside[i].data.currency) == "undefined" || _inside[i].data.currency == null) {
											_inside[i].data.currency = _insideCurrency;
										}
									}
								}
							}

							if (typeof (view.data) == "undefined" || view.data == null) {
								view.data = {};
							}
							view.data.currency = _insideCurrency;

							if (typeof (tracker.visitorData) == "undefined" || tracker.visitorData == null) {
								tracker.visitorData = {};
							}
							tracker.visitorData.currency = _insideCurrency;
						}
					} catch (currencyex) { }

					_inside.push(view);

					log("Inside Debug: ", _inside);
				}
			}
			catch (sendex) {
				_inside = [];

				_inside.push({
					"action": "trackView",
					"type": "other",
					"name": "Check: " + window.location.href
				});

				log(sendex);
			}

			insertInsideTag();
			if (!_insideFirstLoad)
				_insideFirstLoad = true;
		}

		window._insideViewUpdate = debounce(function () {
			var triggerupdate = true;
			try {
				// var temphashj = hashJoaat(JSON.stringify(_insideDataLayer))
				// if (temphashj == _insideHashJ)
				// 	triggerupdate = false;
			} catch (tempex) { }

			if (triggerupdate) {
				sendToInside();
			}
		}, 500);

		var tempview = getViewData();
		if (tempview != null && typeof (tempview.type) != "undefined" && tempview.type != null && tempview.type == "orderconfirmed") {
			deferWait(sendToInside, function () {
				var tempconfirm = orderConfirmProcess();
				if (tempconfirm != null && tempconfirm.length > 0) {
					return true;
				}

				if (document.readyState != 'loading' && document.readyState != 'interactive') {
					deferWait(sendToInside, function () {
						var tempconfirm = orderConfirmProcess();
						if (tempconfirm != null && tempconfirm.length > 0) {
							return true;
						}

						return false;
					});

					return true;
				}
			});
		}
		else {
			deferWait(sendToInside, function () {
				if (document.readyState != 'loading' && document.readyState != 'interactive') {
					keepWait(sendToInside, function () {
						if (!_insideFirstLoad)
							return false;

						if (typeof (_insideGraph) != "undefined" && _insideGraph != null) {
							var temporderdata = getOrderData();

							if (temporderdata != null && temporderdata.length > 0) {
								for (var i = 0; i < temporderdata.length; i++) {
									if (temporderdata[i].action == "trackOrder") {
										if (insideOrderTotal != temporderdata[i].orderTotal) {
											return true;
										}
									}
								}
							}
							else if (insideOrderTotal > 0) {
								insideOrderTotal = 0;
								return true;
							}
						}

						return false;
					});

					return true;
				}

				return false;
			});
		}
	}

	if (typeof (_insideGraph) != "undefined" && _insideGraph != null && typeof (_insideGraph.current) != "undefined" && _insideGraph.current != null) {
		processInside(_insideGraph.current);
	}
	else {
		var insideTracker = {
			"action": "getTracker",
			"crossDomain": false,
			"account": insideAccountKey
		};

		if (typeof (subsiteId) != "undefined" && subsiteId != null)
			insideTracker["subsiteId"] = subsiteId;

		_inside.push(insideTracker);

		_inside.push({
			"action": "bind",
			"name": "onload",
			"callback": function (tracker) {
				if (_insideFirstLoad)
					return;

				_insideJQ = _insideGraph.jQuery;

				processInside(tracker);
			}
		});
		(function (w, d, s, u) {
			a = d.createElement(s), m = d.getElementsByTagName(s)[0];
			a.async = 1;
			a.src = u;
			m.parentNode.insertBefore(a, m);
		})(window, document, "script", "//" + insideTrackerURL + "/ig.js");
	}

})();